FuSeq_WES version v1.0.0 for detection of fusion genes from DNA sequencing data.
Please check the latest version at https://github.com/nghiavtr/FuSeq_WES